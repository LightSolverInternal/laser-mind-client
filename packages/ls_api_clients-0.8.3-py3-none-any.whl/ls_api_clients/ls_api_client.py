import os
import logging
import requests
import json
import time
import msgpack
from ls_cred_storage import LSCredStorage
from laser_mind_client_meta import MessageKeys


class LSAPIClient:

    LS_API_RUN_URL = os.environ['LS_API_RUN_URL'] if 'LS_API_RUN_URL' in os.environ else 'http://solve.lightsolver.com/api/v1/commands/run'
    LS_API_RUN_SECURED_URL = os.environ['LS_API_RUN_SECURED_URL'] if 'LS_API_RUN_SECURED_URL' in os.environ else 'https://solve.lightsolver.com/api/v1/commands/run'
    SOLVER_REQUEST_HEADERS = {'accept' : 'application/octet-stream',
                              'content-type' : 'application/octet-stream',
                              'accept-encoding' : 'gzip, deflate, br'}
    SOLUTION_REQUEST_HEADERS = {
        'accept' : 'application/msgpack',
        'content-type' : 'application/msgpack',
        'accept-encoding' : 'gzip, deflate, br'
    }

    LS_AUTH_URL = os.environ['LS_AUTH_URL'] if 'LS_AUTH_URL' in os.environ else 'https://auth.solve.lightsolver.com/authorize-solver-usage'
    LS_REQUEST_URL = os.environ['LS_REQUEST_URL'] if 'LS_REQUEST_URL' in os.environ else 'https://solve.lightsolver.com/api/v1/getsolution'
    USER_KEY = 'user'
    USER_ID_KEY = 'userId'
    TIMESTAMP_KEY = 'timestamp'
    SESSION_TOKEN_KEY = 'sessionToken'
    ACCESS_TOKEN_KEY = 'accessToken'
    MAX_TOKEN_RETENTION_TIME_SECS = 3500

    def msgpack_encode(self, x):
        v = msgpack.packb(x)
        return v

    def msgpack_decode(self, x):
        try:
            v = msgpack.unpackb(x)
        except Exception as e:
            return None
        return v

    def __init__(self, username, password, printTiming = False, logLevel = logging.INFO):
        self.printTiming = printTiming
        self.username = username
        self.password = password
        self.credStorage = LSCredStorage()
        token_dic = self.check_and_get_persisted_tokens()
        logging.basicConfig(
            filename="laser-mind.log",
            level=logLevel,
            format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %H:%M:%S')
        if token_dic == None:
            self.refresh_tokens_if_needed()
            logging.info('Got new session/access tokens')
        logging.info('connection is authenticated and authorized')


    def refresh_tokens_if_needed(self):
        if not self.check_is_token_valid():
            newTokenDic = self.GetTokensFromServer()
            logging.info(f'got tokens for user {self.username}')
            self.credStorage.update_current_token(newTokenDic)
            self.credStorage.store_token(self.username, newTokenDic)

    def GetTokensFromServer(self):
        data = {
            'user' : f'{self.username}',
            'password' : f'{self.password}'
        }

        headers = {
            'accept' : 'application/json',
            'content-type' : 'application/json',
            }
        req = requests.post(self.LS_AUTH_URL, headers=headers, data=json.dumps(data))
        req.raise_for_status()
        token = req.json()
        token_dic  = self.create_token_data_for_user(token)
        return token_dic

    def create_token_data_for_user(self, token):
        dic = {
            self.USER_KEY : self.username,
            self.SESSION_TOKEN_KEY : token[self.SESSION_TOKEN_KEY],
            self.ACCESS_TOKEN_KEY : token[self.ACCESS_TOKEN_KEY],
            self.USER_ID_KEY : token[self.USER_ID_KEY],
            self.TIMESTAMP_KEY : time.time()
        }
        return dic

    def check_and_get_persisted_tokens(self):
        storedToken = self.credStorage.get_stored_token(self.username)
        if storedToken != None:
            if self.check_is_token_valid():
                return storedToken
        return None

    def check_is_token_valid(self):
        if self.credStorage.currentTokenDic != None:
            return time.time() - self.credStorage.currentTokenDic[self.TIMESTAMP_KEY] < self.MAX_TOKEN_RETENTION_TIME_SECS
        return False

    def MakeDataForAPIRequest(self, commandName, param):
        data = {
            'name' : commandName,
            'username' : self.credStorage.currentTokenDic[self.USER_KEY],
            'userId' : self.credStorage.currentTokenDic[self.USER_ID_KEY],
            'param' : param,
            'sessionToken' : self.credStorage.currentTokenDic[self.SESSION_TOKEN_KEY],
            'accessToken' : self.credStorage.currentTokenDic[self.ACCESS_TOKEN_KEY],
            'creationTime' : time.time()
        }
        return self.msgpack_encode(data)

    def MakeDataForResultRequest(self, solutionId):
        data = {
            'solId' : solutionId,
            'username' : self.credStorage.currentTokenDic[self.USER_KEY],
            'userId' : self.credStorage.currentTokenDic[self.USER_ID_KEY],
            'sessionToken' : self.credStorage.currentTokenDic[self.SESSION_TOKEN_KEY],
            'accessToken' : self.credStorage.currentTokenDic[self.ACCESS_TOKEN_KEY],
            'creationTime' : time.time()
        }
        return self.msgpack_encode(data)

    def ValidateResponse(self, response):
        if response == '"timeout"\n':
            print('Could not locate any Solvers within given timeout')
            return False
        return True

    def SendCommandRequest(self, commandName, input, secured = True):
        if not self.credStorage.is_cached_user(self.username):
            raise SystemError("username doesn't match stored token, please reconnect LightSolver service")
        self.refresh_tokens_if_needed()
        if self.printTiming:
            startTime = time.time()
        data = self.MakeDataForAPIRequest(commandName, input)
        headers = self.SOLVER_REQUEST_HEADERS
        req_url = self.LS_API_RUN_SECURED_URL if secured else self.LS_API_RUN_URL
        response = requests.post(url = req_url, headers = headers, data = data)
        response.raise_for_status()
        dicResponse = self.msgpack_decode(response._content)
        res = None
        if self.ValidateResponse(dicResponse):
            res = dicResponse

        if self.printTiming:
            totalTime = time.time() - startTime
        return res

    def SendResultRequest(self, solutionId, timestamp):
        self.refresh_tokens_if_needed()
        id_str = f'{solutionId}_{timestamp}'
        logging.info(f"getting {id_str}")
        if self.printTiming:
            startTime = time.time()
        data = self.MakeDataForResultRequest(id_str)
        headers = self.SOLUTION_REQUEST_HEADERS
        req_url = self.LS_REQUEST_URL
        response = requests.post(url = req_url, headers = headers, data = data)
        if self.printTiming:
            totalTime = time.time() - startTime
        if response.status_code == 404:
            return None

        response.raise_for_status()
        dicResponse = self.msgpack_decode(response._content)

        if not isinstance(dicResponse, dict):
            raise Exception("response is not a dictionary!")
        if MessageKeys.ERROR_KEY in dicResponse:
            raise Exception(dicResponse[MessageKeys.ERROR_KEY])
        if MessageKeys.WARNING_KEY in dicResponse:
            logging.warning(f"Warning: solver encountered \"{dicResponse[MessageKeys.WARNING_KEY]}\"")
        return dicResponse
